import React, { useState } from 'react';
import { Sparkles, ArrowRight, Check, Code2, Smartphone, Download, Layers, ShieldCheck, ChevronDown, Monitor, Laptop } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { PricingTable } from './PricingTable';

interface LandingPageProps {
  onStartWithPrompt: (promptText: string) => void;
  onNavigate: (view: string) => void;
  onSelectPlan: (planId: 'free' | 'pro' | 'agency') => void;
  onSelectPack: (packId: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStartWithPrompt,
  onNavigate,
  onSelectPlan,
  onSelectPack,
}) => {
  const { isAuthenticated } = useAuth();
  const [demoPrompt, setDemoPrompt] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState<'ecommerce' | 'tech' | 'portfolio'>('tech');

  const samplePrompts = [
    'Loja virtual de café artesanal com catálogo, carrinho e modo escuro',
    'Landing page para SaaS de automação em Inteligência Artificial com preços',
    'Portfólio minimalista para arquiteto de renome com galeria de projetos',
    'Site institucional para clínica médica com agendamento e equipa',
  ];

  const handleDemoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!demoPrompt.trim()) return;
    if (isAuthenticated) {
      onStartWithPrompt(demoPrompt);
    } else {
      // Store prompt in session for post-registration/login auto-generation
      sessionStorage.setItem('pending_prompt', demoPrompt);
      onNavigate('register');
    }
  };

  const handlePromptSelect = (prompt: string) => {
    setDemoPrompt(prompt);
  };

  const faqs = [
    {
      q: 'O que é o StrongX e como funciona a criação de sites com IA?',
      a: 'O StrongX é uma plataforma profissional onde qualquer pessoa pode descrever a sua ideia de website em linguagem natural (por exemplo: "Cria um site para uma agência de tecnologia em tons escuros e com secção de serviços") e o nosso motor de IA constrói um website completo, semântico, moderno e funcional em segundos, pronto para uso.',
    },
    {
      q: 'Como funciona o sistema de 150 créditos?',
      a: 'Cada novo utilizador recebe imediatamente 150 créditos gratuitos ao registar a sua conta. A geração de um website completo consome exatamente 10 créditos, o que permite criar até 15 websites sem qualquer custo. Se uma geração falhar por erro de rede ou do sistema, os seus 10 créditos são automaticamente reembolsados.',
    },
    {
      q: 'Posso exportar o código e alojar no meu próprio servidor?',
      a: 'Sim, absolutamente! A plataforma inclui exportação completa num clique em ficheiro ZIP contendo HTML semântico, ficheiro CSS, scripts JavaScript e documentação, sem dependências proprietárias ou restrições de alojamento.',
    },
    {
      q: 'Posso alterar o site depois de ser gerado pela IA?',
      a: 'Sim. O nosso estúdio inclui um editor conversacional com IA para pedir ajustes ("Torna o menu fixo", "Adiciona tabela com 3 planos de preços", "Muda o tom para azul-escuro"), além de um editor de código interativo com visualização imediata.',
    },
    {
      q: 'Os sites gerados são responsivos para telemóveis e tablets?',
      a: 'Todos os sites gerados pelo StrongX utilizam arquitetura mobile-first com Tailwind CSS de alta precisão. No nosso estúdio de criação, pode alternar a visualização instantaneamente entre Computador, Tablet e Smartphone para validar a experiência antes de exportar.',
    },
  ];

  return (
    <div className="relative overflow-hidden">
      
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-b from-purple-900/15 via-indigo-900/10 to-transparent blur-3xl pointer-events-none" />

      {/* ----------------- HERO SECTION ----------------- */}
      <section className="relative pt-20 pb-16 px-6 max-w-7xl mx-auto text-center">
        
        {/* Subtle unboxed metadata kicker */}
        <div className="inline-flex items-center gap-2 text-xs font-medium text-purple-400 mb-6 bg-purple-500/10 border border-purple-500/20 px-3.5 py-1.5 rounded-full">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>Motor de Inteligência Artificial de Última Geração</span>
          <span aria-hidden="true" className="text-purple-600">·</span>
          <span className="text-slate-300">150 Créditos Grátis no Registo</span>
        </div>

        {/* Main Display Headline with text-wrap: balance */}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-[1.15]" style={{ textWrap: 'balance' }}>
          Transforme as suas ideias em sites profissionais com o poder da{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-indigo-300 to-violet-400">
            Inteligência Artificial.
          </span>
        </h1>

        {/* Subtitle */}
        <p className="mt-6 text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Sem arrastar blocos antiquados nem escrever linhas de código. Descreva o que deseja e o StrongX projeta, estiliza e entrega um website moderno, semântico e responsivo.
        </p>

        {/* Interactive Prompt Box */}
        <div className="mt-10 max-w-2xl mx-auto">
          <form
            onSubmit={handleDemoSubmit}
            className="p-1.5 bg-[#12141F] border border-white/10 rounded-2xl shadow-2xl shadow-purple-950/40 focus-within:border-purple-500/50 transition-all flex flex-col sm:flex-row gap-2"
          >
            <div className="flex-1 flex items-center px-4 py-2">
              <Sparkles className="w-5 h-5 text-purple-400 shrink-0 mr-3" />
              <input
                type="text"
                value={demoPrompt}
                onChange={(e) => setDemoPrompt(e.target.value)}
                placeholder="Ex: Cria um site para uma agência de consultoria financeira com página inicial, serviços..."
                className="w-full bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl hover:from-purple-500 hover:to-indigo-500 shadow-md shadow-purple-600/30 transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
            >
              <span>Gerar Site com IA</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Prompt Suggestions */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5 text-xs text-slate-400">
            <span className="text-slate-500 text-[11px] mr-1">Sugestões rápidas:</span>
            {samplePrompts.slice(0, 3).map((prompt, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handlePromptSelect(prompt)}
                className="hover:text-purple-300 hover:bg-white/5 px-2.5 py-1 rounded-md transition-colors text-slate-400 border border-white/5 cursor-pointer text-left truncate max-w-xs"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>

        {/* Hero Visual Mockup */}
        <div className="mt-14 relative max-w-5xl mx-auto rounded-2xl overflow-hidden border border-white/10 bg-[#0B0D14] shadow-2xl shadow-purple-950/30">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/[0.08] bg-[#0E1019] text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/80" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
              <div className="w-3 h-3 rounded-full bg-green-500/80" />
              <span className="ml-3 font-mono text-[11px] text-slate-500">strongx.studio/builder-live</span>
            </div>
            <div className="flex items-center gap-3 text-slate-400">
              <span className="text-[11px] text-purple-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
                Motor IA Ativo
              </span>
            </div>
          </div>
          <img
            src="/src/assets/images/hero_strongx_showcase_1794357550823.jpg"
            alt="Ambiente de criação de sites StrongX Studio"
            className="w-full h-auto object-cover max-h-[580px]"
            referrerPolicy="no-referrer"
          />
        </div>

      </section>

      {/* ----------------- SHOWCASE SECTION ----------------- */}
      <section id="showcase" className="py-20 px-6 max-w-7xl mx-auto border-t border-white/[0.08]">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-purple-400 mb-2">Exemplos Criados por IA</h2>
          <h3 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Qualquer tipo de website, com rigor profissional
          </h3>
          <p className="mt-3 text-sm text-slate-400">
            Veja a fidelidade visual, estruturação e qualidade do código produzido pela nossa inteligência artificial para diferentes setores de atividade.
          </p>

          {/* Category Tabs */}
          <div className="mt-8 inline-flex items-center p-1 bg-[#12141F] border border-white/10 rounded-xl">
            <button
              onClick={() => setActiveCategory('tech')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-all ${
                activeCategory === 'tech' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tecnologia & SaaS
            </button>
            <button
              onClick={() => setActiveCategory('ecommerce')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-all ${
                activeCategory === 'ecommerce' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Lojas & E-Commerce
            </button>
            <button
              onClick={() => setActiveCategory('portfolio')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-all ${
                activeCategory === 'portfolio' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Agências & Portfólios
            </button>
          </div>
        </div>

        {/* Selected Showcase Presentation */}
        <div className="max-w-4xl mx-auto bg-[#0E1019] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="max-w-md space-y-4">
              <div className="text-xs text-purple-400 font-medium">
                {activeCategory === 'tech' && 'Geração de Landing Page Corporativa'}
                {activeCategory === 'ecommerce' && 'Geração de Loja de Luxo'}
                {activeCategory === 'portfolio' && 'Geração de Portfólio de Agência Criativa'}
              </div>
              <h4 className="text-2xl font-bold text-white">
                {activeCategory === 'tech' && 'Plataforma de Cloud & Robótica'}
                {activeCategory === 'ecommerce' && 'Catálogo Exclusivo de Relojoaria Suíça'}
                {activeCategory === 'portfolio' && 'Estúdio de Design e Experiências Digitais'}
              </h4>
              <p className="text-sm text-slate-400 leading-relaxed">
                {activeCategory === 'tech' && 'Arquitetura modular em Bento grid, modo escuro profundo, secções de métricas de infraestrutura, planos empresariais e chamadas à ação assertivas.'}
                {activeCategory === 'ecommerce' && 'Apresentação de produtos de alta gama, grelha com detalhes de especificações, gaveta de carrinho de compras funcional e finalização de encomenda segura.'}
                {activeCategory === 'portfolio' && 'Tipografia editorial de impacto, cartões de estudos de caso interativos, animações em hover e formulário de contacto direto com validação.'}
              </p>
              <div className="pt-2 flex items-center gap-4 text-xs font-medium text-slate-300">
                <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-purple-400" /> HTML5 Semântico</span>
                <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-purple-400" /> Tailwind CSS</span>
                <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-purple-400" /> Mobile-Ready</span>
              </div>
              <button
                onClick={() => {
                  const prompt = activeCategory === 'tech'
                    ? 'Cria uma landing page para plataforma cloud e robótica com tema dark tech'
                    : activeCategory === 'ecommerce'
                    ? 'Cria uma loja de relógios de luxo com catálogo e carrinho'
                    : 'Cria um portfólio de agência de design com estudos de caso';
                  onStartWithPrompt(prompt);
                }}
                className="mt-4 px-5 py-2.5 text-xs font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/10 rounded-lg transition-colors inline-flex items-center gap-2 cursor-pointer"
              >
                <span>Usar Este Modelo como Base</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="w-full md:w-1/2 rounded-xl overflow-hidden border border-white/10 shadow-lg">
              <img
                src={
                  activeCategory === 'tech'
                    ? '/src/assets/images/showcase_saas_tech_1794357553114.jpg'
                    : activeCategory === 'ecommerce'
                    ? '/src/assets/images/showcase_saas_ecommerce_1794357552686.jpg'
                    : '/src/assets/images/showcase_saas_portfolio_1794357552761.jpg'
                }
                alt="Exemplo gerado por IA"
                className="w-full h-auto object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>

      </section>

      {/* ----------------- FEATURES BENTO GRID ----------------- */}
      <section id="features" className="py-20 px-6 max-w-7xl mx-auto border-t border-white/[0.08]">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-purple-400 mb-2">Engenharia Sem Concessões</h2>
          <h3 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Tudo o que precisa para lançar sites de alta performance
          </h3>
          <p className="mt-3 text-sm text-slate-400">
            Construído para utilizadores exigentes: código limpo, ferramentas de inspeção, responsividade absoluta e total independência.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Semantic Code */}
          <div className="p-6 bg-[#0E1019] border border-white/10 rounded-2xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                <Code2 className="w-5 h-5" />
              </div>
              <h4 className="text-lg font-bold text-white">Código Real & Semântico</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                A IA não cria apenas imagens estáticas: produz HTML5 limpo, Tailwind CSS de última geração e JavaScript interativo acessível e otimizado para motores de busca.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-500">
              <span>Sem dependências presas</span>
              <span aria-hidden="true">·</span>
              <span>Estrutura W3C</span>
            </div>
          </div>

          {/* Card 2: Multi-Device Responsive View */}
          <div className="p-6 bg-[#0E1019] border border-white/10 rounded-2xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <Smartphone className="w-5 h-5" />
              </div>
              <h4 className="text-lg font-bold text-white">Visualização em Tempo Real</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Alterne instantaneamente entre monitores de computador (1440px), tablets (768px) e smartphones (375px) num ambiente de sandbox seguro e responsivo.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-500">
              <span>Desktop</span>
              <span aria-hidden="true">·</span>
              <span>Tablet</span>
              <span aria-hidden="true">·</span>
              <span>Mobile</span>
            </div>
          </div>

          {/* Card 3: ZIP Project Export */}
          <div className="p-6 bg-[#0E1019] border border-white/10 rounded-2xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
                <Download className="w-5 h-5" />
              </div>
              <h4 className="text-lg font-bold text-white">Exportação Completa em ZIP</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Descarregue o pacote com index.html, folhas de estilo e scripts prontos para publicação na Vercel, Netlify, Cloudflare Pages ou qualquer servidor próprio.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-500">
              <span>Zero Vendor Lock-in</span>
              <span aria-hidden="true">·</span>
              <span>1 Clique</span>
            </div>
          </div>

        </div>
      </section>

      {/* ----------------- HOW IT WORKS ----------------- */}
      <section id="how-it-works" className="py-20 px-6 max-w-7xl mx-auto border-t border-white/[0.08]">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-purple-400 mb-2">Processo Simples</h2>
          <h3 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Como funciona a criação no StrongX
          </h3>
          <p className="mt-3 text-sm text-slate-400">
            Apenas três passos separam a sua visão de um website profissional no ar.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="p-6 bg-[#0E1019] border border-white/10 rounded-2xl relative">
            <span className="text-3xl font-black text-purple-500/30 mb-4 block">01</span>
            <h4 className="text-lg font-bold text-white mb-2">Descreva a Sua Visão</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Explique detalhadamente o objetivo do site, o setor de negócio, o esquema de cores preferido e as secções necessárias através de linguagem natural.
            </p>
          </div>

          <div className="p-6 bg-[#0E1019] border border-white/10 rounded-2xl relative">
            <span className="text-3xl font-black text-purple-500/30 mb-4 block">02</span>
            <h4 className="text-lg font-bold text-white mb-2">A IA Sintetiza o Website</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Em segundos, os nossos modelos de inteligência artificial geram a estrutura, o layout visual, os estilos e a lógica interativa sem erros.
            </p>
          </div>

          <div className="p-6 bg-[#0E1019] border border-white/10 rounded-2xl relative">
            <span className="text-3xl font-black text-purple-500/30 mb-4 block">03</span>
            <h4 className="text-lg font-bold text-white mb-2">Refine e Exporte</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Peça modificações pontuais no chat do estúdio, inspecione o código e exporte o projeto em ficheiro ZIP pronto para publicar onde quiser.
            </p>
          </div>

        </div>
      </section>

      {/* ----------------- CREDIT SYSTEM SECTION ----------------- */}
      <section id="credits-system" className="py-20 px-6 max-w-7xl mx-auto border-t border-white/[0.08]">
        <div className="max-w-4xl mx-auto bg-gradient-to-b from-[#131624] to-[#0D0F18] border border-purple-500/30 rounded-3xl p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="text-center max-w-2xl mx-auto mb-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-500/20 text-purple-300 text-xs font-semibold rounded-full mb-3">
              <span>Transparência Total & Sem Surpresas</span>
            </div>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-white">
              150 Créditos Grátis no Momento do Registo
            </h3>
            <p className="mt-3 text-sm text-slate-400 leading-relaxed">
              Acreditamos no poder da nossa tecnologia. É por isso que cada nova conta recebe automaticamente créditos suficientes para construir 15 websites completos.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            
            <div className="p-5 bg-white/[0.03] border border-white/10 rounded-2xl">
              <div className="text-3xl font-black text-purple-400 font-mono tabular-nums">150</div>
              <div className="text-xs font-semibold text-white mt-1">Créditos de Boas-Vindas</div>
              <p className="text-[11px] text-slate-400 mt-2">Atribuídos na criação de conta, sem necessidade de cartão de crédito.</p>
            </div>

            <div className="p-5 bg-white/[0.03] border border-white/10 rounded-2xl">
              <div className="text-3xl font-black text-indigo-400 font-mono tabular-nums">10</div>
              <div className="text-xs font-semibold text-white mt-1">Créditos por Geração</div>
              <p className="text-[11px] text-slate-400 mt-2">Cada site profissional completo consome exatamente 10 créditos do saldo.</p>
            </div>

            <div className="p-5 bg-white/[0.03] border border-white/10 rounded-2xl">
              <div className="text-3xl font-black text-emerald-400 font-mono tabular-nums">100%</div>
              <div className="text-xs font-semibold text-white mt-1">Garantia de Reembolso</div>
              <p className="text-[11px] text-slate-400 mt-2">Se a IA falhar ou o servidor tiver instabilidade, os créditos voltam imediatamente.</p>
            </div>

          </div>

          <div className="mt-10 text-center">
            <button
              onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'register')}
              className="px-8 py-3.5 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 via-indigo-600 to-violet-600 rounded-xl hover:opacity-95 shadow-lg shadow-purple-600/30 transition-all cursor-pointer inline-flex items-center gap-2"
            >
              <span>{isAuthenticated ? 'Ir para o Meu Painel' : 'Começar Gratuitamente com 150 Créditos'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </section>

      {/* ----------------- PRICING SECTION ($ USD / VISA / PAYPAL) ----------------- */}
      <section id="pricing" className="border-t border-white/[0.08]">
        <PricingTable onSelectPlan={onSelectPlan} onSelectPack={onSelectPack} />
      </section>

      {/* ----------------- FAQ SECTION ----------------- */}
      <section id="faq" className="py-20 px-6 max-w-4xl mx-auto border-t border-white/[0.08]">
        <div className="text-center mb-12">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-purple-400 mb-2">Esclareça as Suas Dúvidas</h2>
          <h3 className="text-3xl font-bold text-white tracking-tight">Perguntas Frequentes</h3>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => {
            const isOpen = openFaq === index;
            return (
              <div
                key={index}
                className="bg-[#0E1019] border border-white/10 rounded-xl overflow-hidden transition-all"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : index)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between text-sm font-semibold text-white hover:text-purple-300 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180 text-purple-400' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-6 pb-5 text-xs leading-relaxed text-slate-400 border-t border-white/5 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
};
