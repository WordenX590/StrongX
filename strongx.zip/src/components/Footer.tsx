import React from 'react';
import { Shield, Sparkles } from 'lucide-react';

interface FooterProps {
  onOpenPrivacy: () => void;
  onOpenTerms: () => void;
  onNavigateAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPrivacy, onOpenTerms, onNavigateAdmin }) => {
  return (
    <footer className="w-full border-t border-white/[0.08] bg-[#06070B] text-slate-400 py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start justify-between gap-10">
        
        {/* Brand & Purpose */}
        <div className="max-w-sm space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-[10px] font-black text-white">
              SX
            </div>
            <span className="text-base font-bold text-white tracking-tight">StrongX Studio</span>
          </div>
          <p className="text-xs leading-relaxed text-slate-400">
            Plataforma de criação de websites profissionais de alta conversão impulsionada por Inteligência Artificial. Código limpo, responsividade nativa e arquitetura moderna sem escrever código.
          </p>
          <div className="text-[11px] text-slate-500 pt-1">
            © {new Date().getFullYear()} StrongX Inc. Todos os direitos reservados.
          </div>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-8 text-xs">
          <div>
            <h4 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] mb-3">Plataforma</h4>
            <ul className="space-y-2">
              <li><a href="#features" className="hover:text-white transition-colors">Funcionalidades</a></li>
              <li><a href="#showcase" className="hover:text-white transition-colors">Exemplos de Sites</a></li>
              <li><a href="#how-it-works" className="hover:text-white transition-colors">Como Funciona</a></li>
              <li><a href="#credits-system" className="hover:text-white transition-colors">Sistema de Créditos</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] mb-3">Legal & Privacidade</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={onOpenPrivacy} className="hover:text-white transition-colors text-left cursor-pointer">
                  Política de Privacidade
                </button>
              </li>
              <li>
                <button onClick={onOpenTerms} className="hover:text-white transition-colors text-left cursor-pointer">
                  Termos de Utilização
                </button>
              </li>
              <li>
                <span className="text-slate-500">Conformidade RGPD</span>
              </li>
              <li>
                <span className="text-slate-500">Segurança de Dados</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] mb-3">Administração</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={onNavigateAdmin}
                  className="flex items-center gap-1.5 text-amber-400/90 hover:text-amber-300 transition-colors text-left font-medium"
                >
                  <Shield className="w-3.5 h-3.5 text-amber-400" />
                  <span>Painel do Proprietário</span>
                </button>
              </li>
              <li className="text-slate-500 text-[11px]">
                Acesso restrito ao gestor da plataforma
              </li>
              <li className="text-slate-500 text-[11px]">
                Autenticação de 2 fatores e validação no servidor
              </li>
            </ul>
          </div>
        </div>

      </div>
    </footer>
  );
};
