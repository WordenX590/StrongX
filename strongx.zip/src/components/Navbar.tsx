import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Sparkles, LayoutDashboard, ShieldCheck, LogOut, Code } from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenStudio?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, onOpenStudio }) => {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/[0.08] bg-[#08090E]/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-6 py-3.5">
        
        {/* Zone 1: Single element Brand Wordmark */}
        <button
          onClick={() => onNavigate('landing')}
          className="flex items-center gap-2.5 text-left text-white whitespace-nowrap shrink-0 group focus:outline-none"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 via-indigo-600 to-violet-400 p-[1px] shadow-sm shadow-purple-500/20">
            <div className="w-full h-full bg-[#0B0D14] rounded-[7px] flex items-center justify-center">
              <span className="text-sm font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-300">SX</span>
            </div>
          </div>
          <span className="text-xl font-bold tracking-tight text-white group-hover:text-purple-300 transition-colors">
            Strong<span className="text-purple-500">X</span>
          </span>
        </button>

        {/* Zone 2: 4-5 single-line clean nav links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
          <button
            onClick={() => {
              if (currentView !== 'landing') onNavigate('landing');
              setTimeout(() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' }), 50);
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Funcionalidades
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') onNavigate('landing');
              setTimeout(() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' }), 50);
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Como Funciona
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') onNavigate('landing');
              setTimeout(() => document.getElementById('showcase')?.scrollIntoView({ behavior: 'smooth' }), 50);
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Exemplos
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') onNavigate('landing');
              setTimeout(() => document.getElementById('credits-system')?.scrollIntoView({ behavior: 'smooth' }), 50);
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Créditos
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') onNavigate('landing');
              setTimeout(() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' }), 50);
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Preços ($ USD)
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') onNavigate('landing');
              setTimeout(() => document.getElementById('faq')?.scrollIntoView({ behavior: 'smooth' }), 50);
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Perguntas Frequentes
          </button>
        </nav>

        {/* Zone 3: 1 primary action area */}
        <div className="flex items-center gap-3 shrink-0">
          {!isAuthenticated ? (
            <>
              <button
                onClick={() => onNavigate('login')}
                className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                Iniciar Sessão
              </button>
              <button
                onClick={() => onNavigate('register')}
                className="px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg hover:from-purple-500 hover:to-indigo-500 shadow-sm shadow-purple-600/30 transition-all whitespace-nowrap shrink-0"
              >
                Criar Conta
              </button>
            </>
          ) : (
            <div className="flex items-center gap-2.5">
              {/* Creator Studio Shortcut */}
              <button
                onClick={() => (onOpenStudio ? onOpenStudio() : onNavigate('builder'))}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-purple-300 bg-purple-500/10 border border-purple-500/30 rounded-lg hover:bg-purple-500/20 transition-all whitespace-nowrap shrink-0"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span>Criar Site</span>
              </button>

              {/* Creator Dashboard Button */}
              <button
                onClick={() => onNavigate('dashboard')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 ${
                  currentView === 'dashboard'
                    ? 'bg-white/10 text-white border-white/20'
                    : 'text-slate-300 border-white/5 hover:bg-white/5 hover:text-white'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-slate-400" />
                <span>Painel</span>
              </button>

              {/* Admin Portal if Admin */}
              {isAdmin && (
                <button
                  onClick={() => onNavigate('admin')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 ${
                    currentView === 'admin'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'text-amber-400/90 border-amber-500/20 hover:bg-amber-500/10'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>Admin</span>
                </button>
              )}

              {/* Credit Chip */}
              <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono tabular-nums text-slate-300 bg-white/[0.04] border border-white/[0.08] rounded-md">
                <span className="text-purple-400 font-semibold">{user?.credits ?? 0}</span>
                <span className="text-slate-500 text-[10px]">CR</span>
              </div>

              {/* Logout Button */}
              <button
                onClick={logout}
                title="Terminar Sessão"
                className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};
